#include "Asteroid.h"



Asteroid::Asteroid(SDLGame* game):Container(game)
{

}


Asteroid::~Asteroid()
{
}
