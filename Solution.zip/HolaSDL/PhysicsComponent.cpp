#include "PhysicsComponent.h"

PhysicsComponent::PhysicsComponent() {
	// TODO Auto-generated constructor stub

}

PhysicsComponent::~PhysicsComponent() {
	// TODO Auto-generated destructor stub
}

void PhysicsComponent::update(GameObject* o, Uint32 time)
{

}

