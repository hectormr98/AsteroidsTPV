#include "BonusUpdate.h"



BonusUpdate::BonusUpdate(): InputComponent()
{
}


BonusUpdate::~BonusUpdate()
{
}
