#pragma once
#include"InputComponent.h"
class BonusUpdate: public InputComponent()
{
public:
	BonusUpdate();
	~BonusUpdate();
};

