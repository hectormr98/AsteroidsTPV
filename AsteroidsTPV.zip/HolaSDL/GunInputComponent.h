#pragma once
#include"InputComponent.h"
#include"StarWarsBulletManager.h"
#include"StarTrekBulletManager.h"
#include "Timer.h"

enum class BadgeType {NORMAL, SIXWAYS};
class GunInputComponent: public InputComponent, public Observable
{
protected:
	BulletsManager* manager;
	SDL_Keycode activator;
public:
	GunInputComponent(BulletsManager* bm, SDL_Keycode s, Uint8 shotsPerInterval, Uint32 timeInterval, BadgeType Type);
	~GunInputComponent();
	virtual void handleInput(GameObject* o,Uint32 time, const SDL_Event& e);
private:
	Uint8 disponibleShots;
	Uint32 IntervalTime;
	float auxInterval;
	int auxShots;

	Timer* timer;
	BadgeType badgeType;
};

